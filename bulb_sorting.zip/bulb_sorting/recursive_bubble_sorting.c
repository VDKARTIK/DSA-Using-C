#include <stdio.h>

void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

void recursiveBubbleSort(int arr[], int n) {
    // Base case: If there is only one element or the array is empty, it is already sorted
    if (n <= 1) {
        return;
    }

    // Perform a pass of Bubble Sort
    for (int i = 0; i < n - 1; i++) {
        if (arr[i] > arr[i + 1]) {
            swap(&arr[i], &arr[i + 1]);
        }
    }

    // Recursively call for the remaining elements
    recursiveBubbleSort(arr, n - 1);
}

int main() {
    int n;

    printf("Enter the number of elements: ");
    scanf("%d", &n);

    int arr[n];

    printf("Enter %d elements:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    // Perform Recursive Bubble Sort
    recursiveBubbleSort(arr, n);

    // Display the sorted array
    printf("Sorted array: ");
    for (int i = 0; i <
